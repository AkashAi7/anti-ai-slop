# Anti-slop skills pack

This pack contains 16 skill folders:

- 10 pinned upstream skills from five public repositories, with their licenses and upstream SHA-256 manifest:

  - `systematic-debugging`
  - `test-driven-development`
  - `verification-before-completion`
  - `receiving-code-review`
  - `grill-me`
  - `grilling`
  - `code-simplification`
  - `source-driven-development`
  - `humanizer`
  - `frontend-design`
- 6 original software-development skills authored for Anti-Slop Labs:
  - `security-review`
  - `api-contracts`
  - `dependency-triage`
  - `data-migration-safety`
  - `performance-profiling`
  - `accessibility-review`

The engineering skills have a separate checksum manifest in
`.github/engineering-skills-manifest.json`. Third-party notices apply to the
pinned upstream skills only.

## Add them to your own project

1. Copy the `.github` folder from this ZIP into your repository root. If you
   already have a `.github` folder, merge it without overwriting existing
   files. The skills land in `.github/skills/<name>/`. Copy whole folders,
   not just `SKILL.md`.
2. Do not overwrite an existing skill with the same name.
3. Confirm your client loaded them:
   - VS Code: open the repository, start a Local chat, type `/skills`.
   - GitHub Copilot app: in an Interactive session, run `/skills reload`,
     then `/skills`.

Practice with them in Lab 2: https://akashai7.github.io/anti-ai-slop/site/lab-2.html

These are skill folders, not Copilot built-ins. Read them before use. The
upstream files are unmodified redistributions; the engineering skills are
original to this lab.
