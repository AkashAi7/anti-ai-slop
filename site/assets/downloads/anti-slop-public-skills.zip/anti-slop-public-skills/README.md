# Public anti-slop skills (pinned copies)

Three skills from https://github.com/obra/superpowers, pinned to one upstream
commit, with their MIT license and a SHA-256 manifest:

- `systematic-debugging`
- `test-driven-development`
- `verification-before-completion`

## Add them to your own project

1. Copy the `.github` folder from this ZIP into your repository root. If you
   already have a `.github` folder, merge it: the skills land in
   `.github/skills/<name>/`. Copy whole folders, not just `SKILL.md`.
2. Do not overwrite an existing skill with the same name.
3. Confirm your client loaded them:
   - VS Code: open the repository, start a Local chat, type `/skills`.
   - GitHub Copilot app: in an Interactive session, run `/skills reload`,
     then `/skills`.

Practice with them in Lab 2: https://akashai7.github.io/anti-ai-slop/site/lab-2.html

These are public skills, not Copilot built-ins. Read them before use.
