# Anti-slop lab walkthroughs

10 looping GIFs, before and after posters, and transcripts for presenters:
Lab 1 (/commands + Spec Kit) and Lab 2 (anti-slop skills).

These are illustrative reenactments, not recordings of live Copilot or Spec Kit
output. The test summaries in them come from real fixture runs.

To do the exercises yourself, download anti-slop-lab.zip from https://akashai7.github.io/anti-ai-slop/
